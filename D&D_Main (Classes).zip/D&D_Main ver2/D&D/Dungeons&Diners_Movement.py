import pygame
import sys
import os
pygame.init()

#Name
pygame.display.set_caption("Dungeons and Diners")
world = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
clock = pygame.time.Clock()
bg = pygame.image.load('floor3.png') #This will be th background for the level
sprite = pygame.image.load('chefdude5.png') #this is the sprite for the main character
fps = 60


class Player():
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5


main = True
chef = player(0, 0, 32, 32)
pygame.key.set_repeat(0, 500)
while main:
    world.fill((0,0,0))
    world.blit(bg, (0,0)) #this is implementing the background image
    world.blit(sprite, (chef.x,chef.y)) #this is implementing the main character sprite
    


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit() #This loop will shut down the game when the X is pressed in the top right
            main = False

    keys = pygame.key.get_pressed() #This will allow for movement
    if keys[pygame.K_ESCAPE]:
        pygame.quit()
        try:
            sys.exit() #This will shut down the game when 'ESC' is pressed
        finally:
            main = False
    
    if keys[pygame.K_a] and chef.x > chef.vel: #this will also create a border the main character cant move past
        chef.x -= chef.vel #This will move left when "A" or "LEFT" are pressed 
    if keys[pygame.K_d] and chef.x < 1900 - chef.width - chef.vel:
        chef.x += chef.vel #This will move left when "D" or "RIGHT" are pressed
    if keys[pygame.K_w] and chef.y > chef.vel:
        chef.y -= chef.vel #This will move left when "W" or "UP" are pressed
    if keys[pygame.K_s] and chef.y < 1050 - chef.height - chef.vel:
        chef.y += chef.vel #This will move left when "S" or "DOWN" are pressed
    

    pygame.display.flip()
    pygame.display.update()
    clock.tick(fps) #Decides the the speed at which the game run


pygame.quit()
