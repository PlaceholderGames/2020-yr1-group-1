import pygame, sys, os
from pygame.locals import *
pygame.init()

#Variables
pygame.display.set_caption("Dungeons and Diners")
#world will set the game window to fullscreen
world = pygame.display.set_mode((0,0), HWSURFACE | DOUBLEBUF | pygame.FULLSCREEN)
clock = pygame.time.Clock()
fps = 60
bg = pygame.image.load('floor3.png') #Will set the background image
bg = pygame.transform.scale(bg, (1920, 1080)) #This will upscale the image for fullscreen
logo = pygame.image.load('logo2.png') #Will load the logo for the menu
green = (0,255,0)
red = (255,0,0)
black = (0,0,0)
sprite = pygame.image.load('chefdude5.png') #Will load the main character sprite

class player(object): #sets the class player
    def __init__(self, x, y, width, height):
        self.x = x #sets all the player class variables
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.hit_box = (self.x + 10, self.y, 14, 30)



class enemy(object): #sets the enemy class
    mobs = pygame.image.load("snake.png") #loads in the snake image

    def __init__(self, x, y, width, height, end):
        self.x = x #sets variables for the enemy class
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.vel = 5
        self.path = [self.x, self.end]
        self.hit_box = (self.x + 10, self.y, 14, 30)

    def draw(self,world): #sets the draw function for drawing the hitbox
        ##self.movement()
        if self.vel > 0:
            world.blit(self.mobs, (self.x, self.y))
        self.hit_box = (self.x + 10, self.y, 14, 30)
        pygame.draw.rect(world, red, self.hit_box,2)


    def movement(self): #sets the movement function for enemy movement
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1

def Window(): #this is the function for the window options
    world.fill((0,0,0))
    world.blit(bg, (0,0))
    world.blit(sprite, (chef.x,chef.y))
    snake.draw(world)
    pygame.display.update()



    #Main Loop
chef = player(900, 900, 32, 32)
snake = enemy(910, 910, 32, 32, 910)

menu = True
main = True
while main: #the main loop

    while menu: #The loop for the start menu

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1: #will start the game when clicked
                    menu = False

        clock.tick(30)
        world.blit(logo, (0,0))

        pygame.display.update()
    
    clock.tick(fps)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit() #This loop will shut down the game when the X is pressed in the top right
            main = False

    keys = pygame.key.get_pressed() #This will allow for movement
    if keys[pygame.K_ESCAPE]:
        pygame.quit()
        try:
            sys.exit() #This will shut down the game when 'ESC' is pressed
        finally:
            main = False
    
    if keys[pygame.K_a] and chef.x > chef.vel or keys[pygame.K_LEFT] and chef.x > chef.vel: #this will also create a border the main character cant move past
        chef.x -= chef.vel #This will move left when "A" or "LEFT" are pressed 
    if keys[pygame.K_d] and chef.x < 1910 - chef.width - chef.vel or keys[pygame.K_RIGHT] and chef.x < 1910 - chef.width - chef.vel:
        chef.x += chef.vel #This will move left when "D" or "RIGHT" are pressed
    if keys[pygame.K_w] and chef.y > chef.vel or keys[pygame.K_UP] and chef.y > chef.vel:
        chef.y -= chef.vel #This will move left when "W" or "UP" are pressed
    if keys[pygame.K_s] and chef.y < 1055 - chef.height - chef.vel or keys[pygame.K_DOWN] and chef.y < 1055 - chef.height - chef.vel:
        chef.y += chef.vel #This will move left when "S" or "DOWN" are pressed



    Window()


pygame.quit()
