import pygame
import sys
import os
pygame.init()

#"Game Name"
pygame.display.set_caption("Dungeons and Diners")


#"Variables"
x, y = 5, 5
fps = 30
world = pygame.display.set_mode((900,900)) 
width = 60
height = 60
vel = 5
clock = pygame.time.Clock()

sprite = pygame.image.load('chefdude5.png') #this is the sprite for the main character
bg = pygame.image.load('floor3.png') #This will be the background for the level

main = True
while main:
    world.blit(bg, (0,0)) #this is implementing the background image
    world.blit(sprite, (x,y)) #this is implementing the main character sprite

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit() #This loop will shut down the game when the X is pressed in the top right
            main = False

    if event.type == pygame.KEYDOWN: #This will allow for movement
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
                try:
                    sys.exit() #This will shut down the game when 'ESC' is pressed
                finally:
                    main = False
            if event.key == pygame.K_a and x > vel: #this will also create a border the main character cant move past
                x -= vel #This will move left when "A" or "LEFT" are pressed 
            if event.key == pygame.K_d and x < 890 - width - vel:
                x += vel #This will move left when "D" or "RIGHT" are pressed
            if event.key == pygame.K_w and y > vel:
                y -= vel #This will move left when "W" or "UP" are pressed
            if event.key == pygame.K_s and y < 850 - height - vel:
                y += vel #This will move left when "S" or "DOWN" are pressed


    
    pygame.display.flip() 
    clock.tick(120) #Decides the the speed at which the game run
    pygame.display.update()


pygame.quit()
