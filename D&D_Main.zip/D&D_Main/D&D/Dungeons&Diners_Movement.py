import pygame
import sys
import os
pygame.init()

#Name
pygame.display.set_caption("Dungeons and Diners")


#Variables
x, y = 5, 5
fps = 60
world = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
width = 60
height = 60
vel = 5
stop = 2
clock = pygame.time.Clock()

sprite = pygame.image.load('chefdude5.png') #this is the sprite for the main character

bg = pygame.image.load('floor3.png') #This will be th background for the level

main = True
pygame.key.set_repeat(0, 500)
while main:
    world.fill((0,0,0))
    world.blit(bg, (0,0)) #this is implementing the background image
    world.blit(sprite, (x,y)) #this is implementing the main character sprite

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit() #This loop will shut down the game when the X is pressed in the top right
            main = False

    keys = pygame.key.get_pressed() #This will allow for movement
    if keys[pygame.K_ESCAPE]:
        pygame.quit()
        try:
            sys.exit() #This will shut down the game when 'ESC' is pressed
        finally:
            main = False
    
    if keys[pygame.K_a] and x > vel: #this will also create a border the main character cant move past
        x -= vel #This will move left when "A" or "LEFT" are pressed 
    if keys[pygame.K_d] and x < 1965 - width - vel:
        x += vel #This will move left when "D" or "RIGHT" are pressed
    if keys[pygame.K_w] and y > vel:
        y -= vel #This will move left when "W" or "UP" are pressed
    if keys[pygame.K_s] and y < 1125 - height - vel:
        y += vel #This will move left when "S" or "DOWN" are pressed
    

    pygame.display.flip()
    pygame.display.update()
    clock.tick(fps) #Decides the the speed at which the game run


pygame.quit()
