import pygame
import sys
import os
pygame.init()

#Game Name
pygame.display.set_caption("Dungeons and Diners")


"Variables"
fps = 30 
world = pygame.display.set_mode((0,0), pygame.RESIZABLE) #The resolution that the game will open up at
width = 60 #The width of the character model"
height = 60 #The length of the character model"
vel = 5 #The velocity that the character moves"
forward = 5
left = 5
right = 5
backward = 5

main = True
while main:
    pygame.time.delay(100)#Will make sure that the game doesn't run too quickly"

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit(); sys.exit() #This loop will make sure that when the
            main = False                #game is closed it stops running

    if event.type == pygame.KEYDOWN: #This will allow for movement
            if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                x -= vel #This will move left when "A" or "LEFT" are pressed
            if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                x += vel #This will move left when "D" or "RIGHT" are pressed
            if event.key == pygame.K_UP or event.key == pygame.K_w:
                y -= vel #This will move left when "W" or "UP" are pressed
            if event.key == pygame.K_DOWN or event.key == pygame.K_s:
                y += vel #This will move left when "S" or "DOWN" are pressed

    
        

    world.fill((0,0,0)) #This will fill in where the character is in black
                        #so that the screen wont be filled with characters
    pygame.draw.rect(world, (255,0,0), (x, y, width, height))
    pygame.display.update()


pygame.quit()
